import { useEffect, useState } from "react";
import { useSelector,useDispatch } from "react-redux/es/exports";
import '../Header.css';
import { searchMoviesAction } from "../Redux/Actions"
import logo from "../assets/logo.png"

let Header = ()=>{
  
  const dispatch = useDispatch();
  const [input, setinput]=useState("")
  const searchMovies=useSelector(state=>state.searchMovies)
  console.log(searchMovies)

  const handleChange = (e)=>{
    setinput(e.target.value)
  }

  const handleSubmit =(e)=>{
    e.preventDefault();
    dispatch(searchMoviesAction(input))
    
  }
    return(
    <>
<nav className="navbar">
  <div className="container-fluid">
   <img src={logo} alt={"logo"} style={{height:"0%"}} class="card-img-top"/>
    <form className="d-flex">
      <input className="form-control me-2" onChange={handleChange} type="search" placeholder="Search" aria-label="Search"/>

      <button className="btn" type="submit" onClick={handleSubmit}>Search</button>
    </form>
  </div>
</nav>
    </>
    )
}
export default Header;