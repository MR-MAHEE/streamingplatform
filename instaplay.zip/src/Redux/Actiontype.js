let Actiontype={
    ALL_MOVIES:"ALL_MOVIES",
    SEARCH_MOVIES:"SEARCH_MOVIES",
    SELECTED_MOVIE:"SELECTED_MOVIE"
    }
    export default Actiontype;